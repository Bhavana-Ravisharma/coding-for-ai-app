import os
import fitz  # PyMuPDF
from langchain.vectorstores import FAISS
from langchain.text_splitter import RecursiveCharacterTextSplitter
from model_config import embedding_model

def extract_text_from_pdf(pdf_path):
    doc = fitz.open(pdf_path)
    return "\n".join([page.get_text() for page in doc])

def load_faiss_from_pdf(pdf_path):
    raw_text = extract_text_from_pdf(pdf_path)
    splitter = RecursiveCharacterTextSplitter(chunk_size=800, chunk_overlap=100)
    chunks = splitter.split_text(raw_text)

    db = FAISS.from_texts(chunks, embedding_model)
    db.save_local("faiss_index")
    return db

def load_existing_faiss():
    return FAISS.load_local("faiss_index", embedding_model)