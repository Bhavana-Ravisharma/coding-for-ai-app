from fastapi import FastAPI, Query
from pydantic import BaseModel
from agents import answer_query

app = FastAPI(title="Grade 11 History Chatbot")

class QueryRequest(BaseModel):
    question: str

@app.post("/ask")
def ask_question(payload: QueryRequest):
    response = answer_query(payload.question)
    return response