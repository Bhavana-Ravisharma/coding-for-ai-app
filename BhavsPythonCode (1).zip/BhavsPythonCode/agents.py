from langchain.chains import RetrievalQA
from model_config import llm
from utils import load_existing_faiss

retriever = load_existing_faiss().as_retriever()

rag_chain = RetrievalQA.from_chain_type(
    llm=llm,
    retriever=retriever,
    return_source_documents=True
)

def answer_query(question: str) -> dict:
    result = rag_chain.invoke({"query": question})
    answer = result["result"]
    sources = result["source_documents"]
    references = [{"page": doc.metadata.get("page", 0)} for doc in sources]
    return {
        "answer": answer,
        "references": references
    }